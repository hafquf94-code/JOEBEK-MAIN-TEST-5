// Investor Portal Types

export interface Investor {
  id: string
  name: string
  email: string
  investmentAmount: number
  dailyReturnRate: number // percentage, e.g., 0.5 for 0.5%
  investmentDate: string // ISO date string
  status: "active" | "inactive"
  password?: string
}

export interface InvestorPayment {
  id: string
  investorId: string
  date: string
  amount: number
  method: "bank_transfer" | "cash" | "cheque"
  status: "paid" | "pending"
  recordedBy?: string
}

export interface BusinessRevenue {
  date: string
  amount: number
}

// Calculate daily return amount
export function calculateDailyReturn(investmentAmount: number, dailyReturnRate: number): number {
  return investmentAmount * (dailyReturnRate / 100)
}

// Calculate days since investment
export function calculateDaysSinceInvestment(investmentDate: string): number {
  const start = new Date(investmentDate)
  const today = new Date()
  const diffTime = today.getTime() - start.getTime()
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
  return Math.max(0, diffDays)
}

// Calculate total returns
export function calculateTotalReturns(investmentAmount: number, dailyReturnRate: number, days: number): number {
  return calculateDailyReturn(investmentAmount, dailyReturnRate) * days
}

// Calculate ROI percentage
export function calculateROI(totalReturns: number, investmentAmount: number): number {
  if (investmentAmount === 0) return 0
  return (totalReturns / investmentAmount) * 100
}

// Format currency in Naira
export function formatNaira(amount: number): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

// Format date
export function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

// Generate random password
export function generatePassword(length: number = 10): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"
  let password = ""
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return password
}
