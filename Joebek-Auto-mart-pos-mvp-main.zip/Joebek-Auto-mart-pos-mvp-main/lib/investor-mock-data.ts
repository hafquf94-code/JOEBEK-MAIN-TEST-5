import type { Investor, InvestorPayment, BusinessRevenue } from "./investor-types"

// Mock investors
export const mockInvestors: Investor[] = [
  {
    id: "INV001",
    name: "John Investor",
    email: "john@email.com",
    investmentAmount: 5000000,
    dailyReturnRate: 0.5,
    investmentDate: "2025-11-28",
    status: "active",
    password: "investor123",
  },
  {
    id: "INV002",
    name: "Jane Capital",
    email: "jane@email.com",
    investmentAmount: 3000000,
    dailyReturnRate: 0.4,
    investmentDate: "2025-12-18",
    status: "active",
    password: "capital456",
  },
  {
    id: "INV003",
    name: "Michael Funds",
    email: "michael@email.com",
    investmentAmount: 10000000,
    dailyReturnRate: 0.6,
    investmentDate: "2025-10-01",
    status: "active",
    password: "funds789",
  },
  {
    id: "INV004",
    name: "Sarah Wealth",
    email: "sarah@email.com",
    investmentAmount: 2000000,
    dailyReturnRate: 0.35,
    investmentDate: "2026-01-05",
    status: "inactive",
    password: "wealth321",
  },
]

// Generate payment history for an investor
export function generatePaymentHistory(investor: Investor): InvestorPayment[] {
  const payments: InvestorPayment[] = []
  const startDate = new Date(investor.investmentDate)
  const today = new Date()
  const dailyReturn = investor.investmentAmount * (investor.dailyReturnRate / 100)

  let currentDate = new Date(startDate)
  currentDate.setDate(currentDate.getDate() + 1) // Start from day after investment

  while (currentDate <= today) {
    payments.push({
      id: `PAY-${investor.id}-${payments.length + 1}`,
      investorId: investor.id,
      date: currentDate.toISOString().split("T")[0],
      amount: dailyReturn,
      method: "bank_transfer",
      status: "paid",
      recordedBy: "Admin",
    })
    currentDate.setDate(currentDate.getDate() + 1)
  }

  return payments.reverse() // Most recent first
}

// Generate mock business revenue data (last 30 days)
export function generateRevenueData(): BusinessRevenue[] {
  const data: BusinessRevenue[] = []
  const today = new Date()

  for (let i = 29; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    
    // Random revenue between 150,000 and 400,000
    const baseRevenue = 200000
    const variance = Math.random() * 200000 - 50000
    const dayOfWeek = date.getDay()
    // Weekends have slightly higher sales
    const weekendBonus = (dayOfWeek === 0 || dayOfWeek === 6) ? 50000 : 0

    data.push({
      date: date.toISOString().split("T")[0],
      amount: Math.round(baseRevenue + variance + weekendBonus),
    })
  }

  return data
}

// Get today's revenue
export function getTodayRevenue(revenueData: BusinessRevenue[]): number {
  const today = new Date().toISOString().split("T")[0]
  const todayData = revenueData.find((r) => r.date === today)
  return todayData?.amount || 250000
}

// Get this week's revenue
export function getWeekRevenue(revenueData: BusinessRevenue[]): number {
  const today = new Date()
  const weekAgo = new Date(today)
  weekAgo.setDate(weekAgo.getDate() - 7)

  return revenueData
    .filter((r) => new Date(r.date) >= weekAgo)
    .reduce((sum, r) => sum + r.amount, 0)
}

// Get this month's revenue
export function getMonthRevenue(revenueData: BusinessRevenue[]): number {
  const today = new Date()
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)

  return revenueData
    .filter((r) => new Date(r.date) >= startOfMonth)
    .reduce((sum, r) => sum + r.amount, 0)
}
