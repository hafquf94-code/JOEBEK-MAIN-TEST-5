"use client"

import { Wifi, WifiOff } from "lucide-react"

interface NetworkStatusProps {
  isOnline: boolean
  onToggle?: () => void
}

export function NetworkStatus({ isOnline, onToggle }: NetworkStatusProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
        isOnline ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"
      }`}
      aria-label={isOnline ? "Online" : "Offline Mode"}
    >
      {isOnline ? (
        <>
          <Wifi className="w-4 h-4" />
          <span>Online</span>
        </>
      ) : (
        <>
          <WifiOff className="w-4 h-4" />
          <span>Offline Mode</span>
        </>
      )}
    </button>
  )
}
