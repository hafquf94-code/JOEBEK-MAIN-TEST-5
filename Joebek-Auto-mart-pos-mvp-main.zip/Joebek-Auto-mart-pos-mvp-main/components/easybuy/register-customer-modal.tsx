"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X, Upload, ChevronRight, ChevronLeft, Check } from "lucide-react"
import type { RegistrationStep1, RegistrationStep2, RegistrationStep3, IDCardType } from "@/lib/easybuy-types"

interface RegisterCustomerModalProps {
  onClose: () => void
  onComplete: () => void
}

export function RegisterCustomerModal({ onClose, onComplete }: RegisterCustomerModalProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitted, setIsSubmitted] = useState(false)

  // Form state for each step
  const [step1Data, setStep1Data] = useState<RegistrationStep1>({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    dateOfBirth: "",
    photo: null,
  })

  const [step2Data, setStep2Data] = useState<RegistrationStep2>({
    idCardType: "",
    idNumber: "",
    idPhoto: null,
  })

  const [step3Data, setStep3Data] = useState<RegistrationStep3>({
    guarantorName: "",
    guarantorPhone: "",
    guarantorAddress: "",
    guarantorRelationship: "",
    proposedCreditLimit: 50000,
  })

  const idCardTypes: { value: IDCardType; label: string }[] = [
    { value: "national_id", label: "National ID" },
    { value: "drivers_license", label: "Driver's License" },
    { value: "voters_card", label: "Voter's Card" },
    { value: "international_passport", label: "International Passport" },
  ]

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1)
    } else {
      // Submit the form
      setIsSubmitted(true)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const isStep1Valid = step1Data.fullName && step1Data.phone && step1Data.address
  const isStep2Valid = step2Data.idCardType && step2Data.idNumber
  const isStep3Valid = step3Data.guarantorName && step3Data.guarantorPhone && step3Data.proposedCreditLimit > 0

  const canProceed =
    (currentStep === 1 && isStep1Valid) || (currentStep === 2 && isStep2Valid) || (currentStep === 3 && isStep3Valid)

  if (isSubmitted) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-2">Application Submitted</h2>
          <p className="text-muted-foreground mb-6">
            The customer registration has been submitted for admin approval. You will be notified once it's approved.
          </p>
          <Button onClick={onComplete} className="w-full touch-target">
            Done
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div>
            <h2 className="text-lg font-bold text-foreground">Register New Customer</h2>
            <p className="text-sm text-muted-foreground">Step {currentStep} of 3</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Progress Indicator */}
        <div className="px-4 pt-4">
          <div className="flex items-center justify-between mb-2">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step < currentStep
                      ? "bg-green-500 text-white"
                      : step === currentStep
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {step < currentStep ? <Check className="w-4 h-4" /> : step}
                </div>
                {step < 3 && (
                  <div
                    className={`w-20 sm:w-32 h-1 mx-2 rounded ${step < currentStep ? "bg-green-500" : "bg-muted"}`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mb-4">
            <span>Personal Info</span>
            <span>ID Verification</span>
            <span>Guarantor Info</span>
          </div>
        </div>

        {/* Form Content */}
        <div className="p-4">
          {/* Step 1 - Personal Info */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    value={step1Data.fullName}
                    onChange={(e) => setStep1Data({ ...step1Data, fullName: e.target.value })}
                    placeholder="Enter full name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={step1Data.phone}
                    onChange={(e) => setStep1Data({ ...step1Data, phone: e.target.value })}
                    placeholder="08012345678"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={step1Data.email}
                    onChange={(e) => setStep1Data({ ...step1Data, email: e.target.value })}
                    placeholder="email@example.com"
                    className="mt-1"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    value={step1Data.address}
                    onChange={(e) => setStep1Data({ ...step1Data, address: e.target.value })}
                    placeholder="Enter full address"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="dob">Date of Birth</Label>
                  <Input
                    id="dob"
                    type="date"
                    value={step1Data.dateOfBirth}
                    onChange={(e) => setStep1Data({ ...step1Data, dateOfBirth: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Customer Photo</Label>
                  <Button variant="outline" className="w-full mt-1 touch-target bg-transparent">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Photo
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Step 2 - ID Verification */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="idType">ID Card Type *</Label>
                <select
                  id="idType"
                  value={step2Data.idCardType}
                  onChange={(e) => setStep2Data({ ...step2Data, idCardType: e.target.value as IDCardType })}
                  className="w-full mt-1 h-10 px-3 rounded-md border border-input bg-background text-foreground"
                >
                  <option value="">Select ID type</option>
                  {idCardTypes.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="idNumber">ID Number *</Label>
                <Input
                  id="idNumber"
                  value={step2Data.idNumber}
                  onChange={(e) => setStep2Data({ ...step2Data, idNumber: e.target.value })}
                  placeholder="Enter ID number"
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Upload ID Photo *</Label>
                <div className="mt-1 border-2 border-dashed border-border rounded-lg p-8 text-center">
                  <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">Click or drag to upload ID photo</p>
                  <Button variant="outline" className="mt-3 touch-target bg-transparent">
                    Choose File
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Step 3 - Guarantor Info */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="guarantorName">Guarantor Name *</Label>
                  <Input
                    id="guarantorName"
                    value={step3Data.guarantorName}
                    onChange={(e) => setStep3Data({ ...step3Data, guarantorName: e.target.value })}
                    placeholder="Enter guarantor's full name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="guarantorPhone">Guarantor Phone *</Label>
                  <Input
                    id="guarantorPhone"
                    value={step3Data.guarantorPhone}
                    onChange={(e) => setStep3Data({ ...step3Data, guarantorPhone: e.target.value })}
                    placeholder="08012345678"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="relationship">Relationship</Label>
                  <Input
                    id="relationship"
                    value={step3Data.guarantorRelationship}
                    onChange={(e) => setStep3Data({ ...step3Data, guarantorRelationship: e.target.value })}
                    placeholder="e.g., Spouse, Brother, Friend"
                    className="mt-1"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="guarantorAddress">Guarantor Address</Label>
                  <Input
                    id="guarantorAddress"
                    value={step3Data.guarantorAddress}
                    onChange={(e) => setStep3Data({ ...step3Data, guarantorAddress: e.target.value })}
                    placeholder="Enter guarantor's address"
                    className="mt-1"
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="creditLimit">Proposed Credit Limit *</Label>
                  <div className="relative mt-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₦</span>
                    <Input
                      id="creditLimit"
                      type="number"
                      value={step3Data.proposedCreditLimit}
                      onChange={(e) =>
                        setStep3Data({
                          ...step3Data,
                          proposedCreditLimit: Number.parseInt(e.target.value) || 0,
                        })
                      }
                      className="pl-8"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Subject to admin approval</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-4 border-t border-border">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1}
            className="touch-target bg-transparent"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={!canProceed}
            className="bg-orange-500 hover:bg-orange-600 text-white touch-target"
          >
            {currentStep === 3 ? "Submit Application" : "Next"}
            {currentStep < 3 && <ChevronRight className="w-4 h-4 ml-1" />}
          </Button>
        </div>
      </Card>
    </div>
  )
}
