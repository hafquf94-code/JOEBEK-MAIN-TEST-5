"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Calendar, TrendingUp, TrendingDown, Percent } from "lucide-react"
import type { EasyBuyCustomer } from "@/lib/easybuy-types"
import { MOCK_RISK_SCORES } from "@/lib/easybuy-mock-data"
import { getRiskLevelColor } from "@/lib/easybuy-types"

interface ReportsProps {
  customers: EasyBuyCustomer[]
}

type DateRange = "this_week" | "this_month" | "last_month" | "custom"

export function EasyBuyReports({ customers }: ReportsProps) {
  const [dateRange, setDateRange] = useState<DateRange>("this_month")

  // Mock performance metrics
  const metrics = {
    totalNewCreditSales: 425000,
    totalPaymentsReceived: 285000,
    collectionRate: 67,
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="p-4 space-y-4">
      {/* Date Range Selector */}
      <Card className="p-4">
        <div className="flex items-center gap-2 flex-wrap">
          <Calendar className="w-5 h-5 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground mr-2">Date Range:</span>
          {[
            { value: "this_week", label: "This Week" },
            { value: "this_month", label: "This Month" },
            { value: "last_month", label: "Last Month" },
            { value: "custom", label: "Custom Range" },
          ].map((range) => (
            <Button
              key={range.value}
              variant={dateRange === range.value ? "default" : "outline"}
              size="sm"
              onClick={() => setDateRange(range.value as DateRange)}
              className="touch-target"
            >
              {range.label}
            </Button>
          ))}
        </div>
      </Card>

      {/* Collection Performance Metrics */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">New Credit Sales</p>
              <p className="text-xl font-bold text-foreground">{formatCurrency(metrics.totalNewCreditSales)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <TrendingDown className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Payments Received</p>
              <p className="text-xl font-bold text-green-600">{formatCurrency(metrics.totalPaymentsReceived)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
              <Percent className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Collection Rate</p>
              <p className="text-xl font-bold text-purple-600">{metrics.collectionRate}%</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Export Buttons */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-3">Export Reports</h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" className="touch-target bg-transparent">
            <Download className="w-4 h-4 mr-2" />
            Export Customer List
          </Button>
          <Button variant="outline" className="touch-target bg-transparent">
            <Download className="w-4 h-4 mr-2" />
            Export Payment History
          </Button>
          <Button variant="outline" className="touch-target bg-transparent">
            <Download className="w-4 h-4 mr-2" />
            Export Debt Report
          </Button>
        </div>
      </Card>

      {/* Customer Risk Scores */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-4">Customer Risk Scores</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Customer</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground">Risk Level</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {MOCK_RISK_SCORES.map((score) => (
                <tr key={score.customerId} className="hover:bg-muted/30">
                  <td className="px-4 py-3">
                    <span className="font-medium text-foreground">{score.customerName}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${getRiskLevelColor(
                        score.riskLevel,
                      )}`}
                    >
                      {score.riskLevel}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{score.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
