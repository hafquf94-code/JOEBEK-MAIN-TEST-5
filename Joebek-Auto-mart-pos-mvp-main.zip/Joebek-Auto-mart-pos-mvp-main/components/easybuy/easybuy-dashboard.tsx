"use client"

import { useState } from "react"
import { EasyBuyCustomerList } from "./customer-list"
import { EasyBuyDebtOverview } from "./debt-overview"
import { EasyBuyReports } from "./reports"
import { CustomerDetailView } from "./customer-detail-view"
import { RegisterCustomerModal } from "./register-customer-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, UserPlus, ArrowLeft } from "lucide-react"
import type { EasyBuyCustomer } from "@/lib/easybuy-types"
import { MOCK_EASYBUY_CUSTOMERS } from "@/lib/easybuy-mock-data"

type TabType = "customers" | "debt-overview" | "reports"

interface EasyBuyDashboardProps {
  staffName: string
  onBack: () => void
}

export function EasyBuyDashboard({ staffName, onBack }: EasyBuyDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>("customers")
  const [searchQuery, setSearchQuery] = useState("")
  const [showRegisterModal, setShowRegisterModal] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState<EasyBuyCustomer | null>(null)
  const [customers, setCustomers] = useState<EasyBuyCustomer[]>(MOCK_EASYBUY_CUSTOMERS)

  const handleCustomerSelect = (customer: EasyBuyCustomer) => {
    setSelectedCustomer(customer)
  }

  const handleBackToList = () => {
    setSelectedCustomer(null)
  }

  const handleRegisterComplete = () => {
    setShowRegisterModal(false)
  }

  const handleUpdateCustomer = (updatedCustomer: EasyBuyCustomer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updatedCustomer.id ? updatedCustomer : c)))
    setSelectedCustomer(updatedCustomer)
  }

  // If a customer is selected, show detail view
  if (selectedCustomer) {
    return (
      <CustomerDetailView
        customer={selectedCustomer}
        staffName={staffName}
        onBack={handleBackToList}
        onUpdateCustomer={handleUpdateCustomer}
      />
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back to POS
            </Button>
            <div className="h-6 w-px bg-border" />
            <div>
              <h1 className="font-bold text-foreground text-lg">Easy Buy Management</h1>
              <p className="text-xs text-muted-foreground">Customer Credit System</p>
            </div>
          </div>

          {/* Register Button - Only show on customers tab */}
          {activeTab === "customers" && (
            <Button
              onClick={() => setShowRegisterModal(true)}
              className="bg-orange-500 hover:bg-orange-600 text-white touch-target"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Register New Customer
            </Button>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 mt-4">
          <button
            onClick={() => setActiveTab("customers")}
            className={`px-4 py-2 rounded-t-lg font-medium transition-colors touch-target ${
              activeTab === "customers"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            Customers
          </button>
          <button
            onClick={() => setActiveTab("debt-overview")}
            className={`px-4 py-2 rounded-t-lg font-medium transition-colors touch-target ${
              activeTab === "debt-overview"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            Debt Overview
          </button>
          <button
            onClick={() => setActiveTab("reports")}
            className={`px-4 py-2 rounded-t-lg font-medium transition-colors touch-target ${
              activeTab === "reports"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            Reports
          </button>
        </div>
      </header>

      {/* Search Bar - Only for customers tab */}
      {activeTab === "customers" && (
        <div className="bg-card border-b border-border px-4 py-3">
          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search by name, phone, or Easy Buy ID"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-11"
            />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === "customers" && (
          <EasyBuyCustomerList
            customers={customers}
            searchQuery={searchQuery}
            onSelectCustomer={handleCustomerSelect}
          />
        )}
        {activeTab === "debt-overview" && <EasyBuyDebtOverview />}
        {activeTab === "reports" && <EasyBuyReports customers={customers} />}
      </div>

      {/* Register Modal */}
      {showRegisterModal && (
        <RegisterCustomerModal onClose={() => setShowRegisterModal(false)} onComplete={handleRegisterComplete} />
      )}
    </div>
  )
}
