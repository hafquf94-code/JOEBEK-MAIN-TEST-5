"use client"

import { useState, useMemo } from "react"
import { Car, LogOut, TrendingUp, Calendar, DollarSign, Percent, BarChart3, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import type { Investor } from "@/lib/investor-types"
import {
  calculateDailyReturn,
  calculateDaysSinceInvestment,
  calculateTotalReturns,
  calculateROI,
  formatNaira,
  formatDate,
} from "@/lib/investor-types"
import {
  generateRevenueData,
  getTodayRevenue,
  getWeekRevenue,
  getMonthRevenue,
} from "@/lib/investor-mock-data"

interface InvestorDashboardProps {
  investor: Investor
  onLogout: () => void
}

export function InvestorDashboard({ investor, onLogout }: InvestorDashboardProps) {
  const revenueData = useMemo(() => generateRevenueData(), [])

  const daysSinceInvestment = calculateDaysSinceInvestment(investor.investmentDate)
  const dailyReturn = calculateDailyReturn(investor.investmentAmount, investor.dailyReturnRate)
  const totalReturns = calculateTotalReturns(investor.investmentAmount, investor.dailyReturnRate, daysSinceInvestment)
  const roi = calculateROI(totalReturns, investor.investmentAmount)

  // Calculate cumulative returns
  const today = new Date()
  const dayOfWeek = today.getDay()
  const daysThisWeek = dayOfWeek === 0 ? 7 : dayOfWeek
  const dayOfMonth = today.getDate()

  const weeklyReturn = dailyReturn * Math.min(daysThisWeek, daysSinceInvestment)
  const monthlyReturn = dailyReturn * Math.min(dayOfMonth, daysSinceInvestment)

  // Business revenue
  const todayRevenue = getTodayRevenue(revenueData)
  const weekRevenue = getWeekRevenue(revenueData)
  const monthRevenue = getMonthRevenue(revenueData)

  // Format chart data
  const chartData = revenueData.map((item) => ({
    date: new Date(item.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    revenue: item.amount,
  }))

  const isNewInvestor = daysSinceInvestment === 0

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
                <Car className="h-5 w-5" />
              </div>
              <div>
                <h1 className="font-bold text-blue-900">JOEBEK AUTO-MART</h1>
                <p className="text-xs text-orange-600 font-medium">Investor Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground hidden sm:block">
                Welcome back, <span className="font-medium text-foreground">{investor.name}</span>
              </span>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* New Investor Welcome */}
        {isNewInvestor && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="p-6">
              <h3 className="font-semibold text-blue-900 mb-2">Welcome to JOEBEK AUTO-MART Investor Portal!</h3>
              <p className="text-sm text-blue-700">
                Your investment is being processed. Returns will appear starting tomorrow.
              </p>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <p className="text-xs text-blue-600">Investment Amount</p>
                  <p className="font-bold text-blue-900">{formatNaira(investor.investmentAmount)}</p>
                </div>
                <div>
                  <p className="text-xs text-blue-600">Daily Return Rate</p>
                  <p className="font-bold text-blue-900">{investor.dailyReturnRate}%</p>
                </div>
                <div>
                  <p className="text-xs text-blue-600">Expected Daily Return</p>
                  <p className="font-bold text-blue-900">{formatNaira(dailyReturn)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Investment Overview */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-blue-600" />
              Your Investment Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Investor Name</p>
                <p className="font-semibold text-lg">{investor.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Investment Amount</p>
                <p className="font-bold text-2xl text-blue-600">{formatNaira(investor.investmentAmount)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Investment Date</p>
                <p className="font-semibold text-lg">{formatDate(investor.investmentDate)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Daily Return Rate</p>
                <p className="font-bold text-2xl text-green-600">{investor.dailyReturnRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Today's Returns */}
        <Card className="mb-6 border-green-200">
          <CardHeader className="pb-3 bg-green-50 rounded-t-lg">
            <CardTitle className="text-lg flex items-center gap-2 text-green-800">
              <Calendar className="h-5 w-5" />
              Today's Returns
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Date</p>
                <p className="font-semibold text-lg">
                  {new Date().toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Daily Return</p>
                <p className="font-bold text-3xl text-green-600">{formatNaira(dailyReturn)}</p>
              </div>
              <div className="flex items-center">
                <p className="text-sm text-muted-foreground bg-gray-100 px-3 py-2 rounded-md">
                  ({investor.dailyReturnRate}% of {formatNaira(investor.investmentAmount)})
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cumulative Returns */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card className="border-t-4 border-t-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-blue-600" />
                <p className="text-sm font-medium text-muted-foreground">THIS WEEK</p>
              </div>
              <p className="font-bold text-2xl text-blue-600">{formatNaira(weeklyReturn)}</p>
              <p className="text-xs text-muted-foreground mt-1">
                ({Math.min(daysThisWeek, daysSinceInvestment)} days)
              </p>
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-orange-500">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4 text-orange-600" />
                <p className="text-sm font-medium text-muted-foreground">THIS MONTH</p>
              </div>
              <p className="font-bold text-2xl text-orange-600">{formatNaira(monthlyReturn)}</p>
              <p className="text-xs text-muted-foreground mt-1">
                ({Math.min(dayOfMonth, daysSinceInvestment)} days)
              </p>
            </CardContent>
          </Card>
          <Card className="border-t-4 border-t-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <p className="text-sm font-medium text-muted-foreground">TOTAL</p>
              </div>
              <p className="font-bold text-2xl text-green-600">{formatNaira(totalReturns)}</p>
              <p className="text-xs text-muted-foreground mt-1">({daysSinceInvestment} days)</p>
            </CardContent>
          </Card>
        </div>

        {/* ROI Card */}
        <Card className="mb-6 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Percent className="h-5 w-5" />
              Return on Investment (ROI)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              <div>
                <p className="text-sm text-blue-200">Total Returns to Date</p>
                <p className="font-bold text-2xl">{formatNaira(totalReturns)}</p>
              </div>
              <div>
                <p className="text-sm text-blue-200">Investment Amount</p>
                <p className="font-bold text-2xl">{formatNaira(investor.investmentAmount)}</p>
              </div>
              <div>
                <p className="text-sm text-blue-200">ROI Percentage</p>
                <p className="font-bold text-3xl text-green-300">{roi.toFixed(1)}%</p>
              </div>
              <div>
                <p className="text-sm text-blue-200">Days Since Investment</p>
                <p className="font-bold text-2xl">{daysSinceInvestment} days</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Business Performance Summary */}
        <Card className="mb-6 border-orange-200">
          <CardHeader className="pb-3 bg-orange-50 rounded-t-lg">
            <CardTitle className="text-lg flex items-center gap-2 text-orange-800">
              <BarChart3 className="h-5 w-5" />
              Business Performance Summary
            </CardTitle>
            <CardDescription className="text-orange-700">
              Revenue shown for transparency. Your returns are calculated on investment amount.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Today's Total Revenue</p>
                <p className="font-bold text-2xl text-orange-600">{formatNaira(todayRevenue)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">This Week's Revenue</p>
                <p className="font-bold text-2xl text-orange-600">{formatNaira(weekRevenue)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">This Month's Revenue</p>
                <p className="font-bold text-2xl text-orange-600">{formatNaira(monthRevenue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Trend Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Revenue Trend (Last 30 Days)</CardTitle>
            <CardDescription>Daily business revenue for investor transparency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11 }}
                    tickLine={false}
                    axisLine={{ stroke: "#e5e7eb" }}
                    interval="preserveStartEnd"
                  />
                  <YAxis
                    tick={{ fontSize: 11 }}
                    tickLine={false}
                    axisLine={{ stroke: "#e5e7eb" }}
                    tickFormatter={(value) => `₦${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    formatter={(value: number) => [formatNaira(value), "Revenue"]}
                    labelStyle={{ fontWeight: "bold" }}
                    contentStyle={{
                      borderRadius: "8px",
                      border: "1px solid #e5e7eb",
                      boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="#2563eb"
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 6, fill: "#2563eb" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-8 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-muted-foreground">
            JOEBEK AUTO-MART Investor Portal - All information is read-only
          </p>
        </div>
      </footer>
    </div>
  )
}
