"use client"

import { Bell, ChevronRight, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { SidebarTrigger } from "@/components/ui/sidebar"
import type { AdminPage } from "./admin-sidebar"

interface AdminHeaderProps {
  currentPage: AdminPage
  adminEmail: string
  onLogout: () => void
}

const pageLabels: Record<AdminPage, string> = {
  dashboard: "Dashboard",
  products: "Products",
  orders: "Orders",
  inventory: "Inventory",
  analytics: "Analytics",
  easybuy: "Easy Buy",
  settings: "Settings",
}

export function AdminHeader({ currentPage, adminEmail, onLogout }: AdminHeaderProps) {
  const notificationCount = 5

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4">
      <SidebarTrigger />

      {/* Breadcrumb */}
      <nav className="flex items-center gap-1 text-sm">
        <span className="text-muted-foreground">Admin</span>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
        <span className="font-medium">{pageLabels[currentPage]}</span>
      </nav>

      <div className="flex-1" />

      {/* Notifications */}
      <Button variant="ghost" size="icon" className="relative">
        <Bell className="h-5 w-5" />
        {notificationCount > 0 && (
          <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs">
            {notificationCount}
          </Badge>
        )}
        <span className="sr-only">Notifications</span>
      </Button>

      {/* Profile Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="flex items-center gap-2 px-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/admin-avatar.png" />
              <AvatarFallback>
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <span className="hidden md:inline-block text-sm font-medium">{adminEmail.split("@")[0]}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem>
            <User className="mr-2 h-4 w-4" />
            My Profile
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onLogout} className="text-red-600">
            <span>Logout</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
