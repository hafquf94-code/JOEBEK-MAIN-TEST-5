"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AdminSidebar, type AdminPage } from "./admin-sidebar"
import { AdminHeader } from "./admin-header"
import { DashboardHome } from "./dashboard-home"
import { AnalyticsPage } from "./analytics-page"
import { InvestorsPage } from "./investors-page"

interface AdminDashboardProps {
  adminEmail: string
  onLogout: () => void
}

export function AdminDashboard({ adminEmail, onLogout }: AdminDashboardProps) {
  const [currentPage, setCurrentPage] = useState<AdminPage>("dashboard")

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <DashboardHome />
      case "analytics":
        return <AnalyticsPage />
      case "products":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold">Products</h1>
            <p className="text-muted-foreground">Product management coming soon...</p>
          </div>
        )
      case "orders":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold">Orders</h1>
            <p className="text-muted-foreground">Order management coming soon...</p>
          </div>
        )
      case "inventory":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold">Inventory</h1>
            <p className="text-muted-foreground">Inventory management coming soon...</p>
          </div>
        )
      case "easybuy":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold">Easy Buy</h1>
            <p className="text-muted-foreground">Easy Buy credit management coming soon...</p>
          </div>
        )
      case "investors":
        return <InvestorsPage />
      case "settings":
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold">Settings</h1>
            <p className="text-muted-foreground">Settings coming soon...</p>
          </div>
        )
      default:
        return <DashboardHome />
    }
  }

  return (
    <SidebarProvider>
      <AdminSidebar currentPage={currentPage} onPageChange={setCurrentPage} onLogout={onLogout} />
      <SidebarInset>
        <AdminHeader currentPage={currentPage} adminEmail={adminEmail} onLogout={onLogout} />
        <main className="flex-1 overflow-auto">{renderPage()}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
