"use client"

import { useState } from "react"
import { Plus, Search, Edit, Eye, UserCheck, UserX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { mockInvestors } from "@/lib/investor-mock-data"
import type { Investor } from "@/lib/investor-types"
import {
  calculateDailyReturn,
  calculateDaysSinceInvestment,
  calculateTotalReturns,
  formatNaira,
  formatDate,
} from "@/lib/investor-types"
import { AddInvestorModal } from "./add-investor-modal"
import { ViewInvestorModal } from "./view-investor-modal"

export function InvestorsPage() {
  const [investors, setInvestors] = useState<Investor[]>(mockInvestors)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddModal, setShowAddModal] = useState(false)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedInvestor, setSelectedInvestor] = useState<Investor | null>(null)
  const [editMode, setEditMode] = useState(false)

  const filteredInvestors = investors.filter(
    (inv) =>
      inv.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalInvestment = investors.reduce((sum, inv) => sum + inv.investmentAmount, 0)
  const totalPaid = investors.reduce((sum, inv) => {
    const days = calculateDaysSinceInvestment(inv.investmentDate)
    return sum + calculateTotalReturns(inv.investmentAmount, inv.dailyReturnRate, days)
  }, 0)

  const handleAddInvestor = (newInvestor: Investor) => {
    setInvestors([...investors, newInvestor])
    setShowAddModal(false)
  }

  const handleUpdateInvestor = (updatedInvestor: Investor) => {
    setInvestors(investors.map((inv) => (inv.id === updatedInvestor.id ? updatedInvestor : inv)))
    setShowViewModal(false)
    setSelectedInvestor(null)
    setEditMode(false)
  }

  const handleViewInvestor = (investor: Investor) => {
    setSelectedInvestor(investor)
    setEditMode(false)
    setShowViewModal(true)
  }

  const handleEditInvestor = (investor: Investor) => {
    setSelectedInvestor(investor)
    setEditMode(true)
    setShowViewModal(true)
  }

  const handleToggleStatus = (investor: Investor) => {
    const updatedInvestor = {
      ...investor,
      status: investor.status === "active" ? "inactive" : "active",
    } as Investor
    handleUpdateInvestor(updatedInvestor)
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Investor Management</h1>
          <p className="text-muted-foreground">Manage investor accounts and track returns</p>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="bg-orange-500 hover:bg-orange-600">
          <Plus className="h-4 w-4 mr-2" />
          Add Investor
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Investors List */}
      {filteredInvestors.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No investors registered yet</p>
            <p className="text-sm text-muted-foreground mb-6">
              Click "Add Investor" to register your first investor and start tracking returns.
            </p>
            <Button onClick={() => setShowAddModal(true)} className="bg-orange-500 hover:bg-orange-600">
              <Plus className="h-4 w-4 mr-2" />
              Add First Investor
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                      Email
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                      Investment
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                      Daily %
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                      Total Paid
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">
                      Status
                    </th>
                    <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredInvestors.map((investor) => {
                    const days = calculateDaysSinceInvestment(investor.investmentDate)
                    const totalPaid = calculateTotalReturns(
                      investor.investmentAmount,
                      investor.dailyReturnRate,
                      days
                    )
                    return (
                      <tr key={investor.id} className="hover:bg-gray-50">
                        <td className="py-4 px-4">
                          <div>
                            <p className="font-medium">{investor.name}</p>
                            <p className="text-xs text-muted-foreground">
                              Active since: {formatDate(investor.investmentDate)}
                            </p>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-sm">{investor.email}</td>
                        <td className="py-4 px-4 text-right font-semibold text-blue-600">
                          {formatNaira(investor.investmentAmount)}
                        </td>
                        <td className="py-4 px-4 text-right font-medium text-green-600">
                          {investor.dailyReturnRate}%
                        </td>
                        <td className="py-4 px-4 text-right font-medium">
                          {formatNaira(totalPaid)}
                        </td>
                        <td className="py-4 px-4 text-center">
                          <Badge
                            variant={investor.status === "active" ? "default" : "secondary"}
                            className={
                              investor.status === "active"
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-600"
                            }
                          >
                            {investor.status === "active" ? "Active" : "Inactive"}
                          </Badge>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center justify-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditInvestor(investor)}
                              title="Edit"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleViewInvestor(investor)}
                              title="View"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleStatus(investor)}
                              title={investor.status === "active" ? "Deactivate" : "Activate"}
                            >
                              {investor.status === "active" ? (
                                <UserX className="h-4 w-4 text-red-500" />
                              ) : (
                                <UserCheck className="h-4 w-4 text-green-500" />
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="py-4">
            <p className="text-sm text-blue-700">Total Investment Amount</p>
            <p className="text-2xl font-bold text-blue-900">{formatNaira(totalInvestment)}</p>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50">
          <CardContent className="py-4">
            <p className="text-sm text-green-700">Total Paid to Investors</p>
            <p className="text-2xl font-bold text-green-900">{formatNaira(totalPaid)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Add Investor Modal */}
      <AddInvestorModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSave={handleAddInvestor}
      />

      {/* View/Edit Investor Modal */}
      {selectedInvestor && (
        <ViewInvestorModal
          open={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedInvestor(null)
            setEditMode(false)
          }}
          investor={selectedInvestor}
          editMode={editMode}
          onSave={handleUpdateInvestor}
          onEdit={() => setEditMode(true)}
        />
      )}
    </div>
  )
}
