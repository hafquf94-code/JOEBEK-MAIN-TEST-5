"use client"

import { useState, useMemo } from "react"
import { Edit, Download, Printer, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import type { Investor, InvestorPayment } from "@/lib/investor-types"
import {
  calculateDailyReturn,
  calculateDaysSinceInvestment,
  calculateTotalReturns,
  calculateROI,
  formatNaira,
  formatDate,
  generatePassword,
} from "@/lib/investor-types"
import { generatePaymentHistory } from "@/lib/investor-mock-data"

interface ViewInvestorModalProps {
  open: boolean
  onClose: () => void
  investor: Investor
  editMode: boolean
  onSave: (investor: Investor) => void
  onEdit: () => void
}

export function ViewInvestorModal({
  open,
  onClose,
  investor,
  editMode,
  onSave,
  onEdit,
}: ViewInvestorModalProps) {
  const [formData, setFormData] = useState<Investor>(investor)
  const paymentHistory = useMemo(() => generatePaymentHistory(investor), [investor])

  const daysSinceInvestment = calculateDaysSinceInvestment(investor.investmentDate)
  const dailyReturn = calculateDailyReturn(investor.investmentAmount, investor.dailyReturnRate)
  const totalReturns = calculateTotalReturns(
    investor.investmentAmount,
    investor.dailyReturnRate,
    daysSinceInvestment
  )
  const roi = calculateROI(totalReturns, investor.investmentAmount)

  const handleSave = () => {
    onSave({
      ...formData,
      investmentAmount: Number(formData.investmentAmount),
      dailyReturnRate: Number(formData.dailyReturnRate),
    })
  }

  const handleGeneratePassword = () => {
    setFormData({ ...formData, password: generatePassword() })
  }

  // Reset form data when investor changes
  useState(() => {
    setFormData(investor)
  })

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>
                {editMode ? "Edit Investor" : "Investor Details"}: {investor.name}
              </DialogTitle>
              <DialogDescription>
                {editMode ? "Update investor information" : "View investor account details and payment history"}
              </DialogDescription>
            </div>
            {!editMode && (
              <Button variant="outline" size="sm" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
          </div>
        </DialogHeader>

        {editMode ? (
          /* Edit Form */
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Full Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-amount">Investment Amount (₦)</Label>
                <Input
                  id="edit-amount"
                  type="number"
                  value={formData.investmentAmount}
                  onChange={(e) =>
                    setFormData({ ...formData, investmentAmount: Number(e.target.value) })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-rate">Daily Return Rate (%)</Label>
                <Input
                  id="edit-rate"
                  type="number"
                  step="0.01"
                  value={formData.dailyReturnRate}
                  onChange={(e) =>
                    setFormData({ ...formData, dailyReturnRate: Number(e.target.value) })
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-date">Investment Start Date</Label>
                <Input
                  id="edit-date"
                  type="date"
                  value={formData.investmentDate}
                  onChange={(e) => setFormData({ ...formData, investmentDate: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-password">Password</Label>
                <div className="flex gap-2">
                  <Input
                    id="edit-password"
                    value={formData.password || ""}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={handleGeneratePassword}
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <RadioGroup
                value={formData.status}
                onValueChange={(value) =>
                  setFormData({ ...formData, status: value as "active" | "inactive" })
                }
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="active" id="edit-active" />
                  <Label htmlFor="edit-active" className="font-normal cursor-pointer">
                    Active
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="inactive" id="edit-inactive" />
                  <Label htmlFor="edit-inactive" className="font-normal cursor-pointer">
                    Inactive
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1 bg-transparent">
                Cancel
              </Button>
              <Button onClick={handleSave} className="flex-1 bg-blue-600 hover:bg-blue-700">
                Save Changes
              </Button>
            </div>
          </div>
        ) : (
          /* View Details */
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="payments">Payment History</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-6 pt-4">
              {/* Basic Information */}
              <div>
                <h4 className="font-semibold text-sm text-muted-foreground mb-3">
                  BASIC INFORMATION
                </h4>
                <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
                  <div>
                    <p className="text-xs text-muted-foreground">Name</p>
                    <p className="font-medium">{investor.name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="font-medium">{investor.email}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Investment Amount</p>
                    <p className="font-bold text-blue-600">
                      {formatNaira(investor.investmentAmount)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Daily Rate</p>
                    <p className="font-bold text-green-600">{investor.dailyReturnRate}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Start Date</p>
                    <p className="font-medium">{formatDate(investor.investmentDate)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Days Active</p>
                    <p className="font-medium">{daysSinceInvestment} days</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Status</p>
                    <Badge
                      variant={investor.status === "active" ? "default" : "secondary"}
                      className={
                        investor.status === "active"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-600"
                      }
                    >
                      {investor.status === "active" ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Returns Summary */}
              <div>
                <h4 className="font-semibold text-sm text-muted-foreground mb-3">
                  RETURNS SUMMARY
                </h4>
                <div className="grid grid-cols-2 gap-4 bg-green-50 p-4 rounded-lg">
                  <div>
                    <p className="text-xs text-green-700">Daily Return</p>
                    <p className="font-bold text-green-800">{formatNaira(dailyReturn)}</p>
                    <p className="text-xs text-green-600">
                      ({investor.dailyReturnRate}% of {formatNaira(investor.investmentAmount)})
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-green-700">Total Paid</p>
                    <p className="font-bold text-green-800">{formatNaira(totalReturns)}</p>
                    <p className="text-xs text-green-600">
                      ({daysSinceInvestment} days x {formatNaira(dailyReturn)})
                    </p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-xs text-green-700">ROI to Date</p>
                    <p className="font-bold text-2xl text-green-800">{roi.toFixed(1)}%</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  Download Report
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="payments" className="pt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm text-muted-foreground">
                    PAYMENT HISTORY ({paymentHistory.length} payments)
                  </h4>
                </div>

                {paymentHistory.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No payments recorded yet
                  </div>
                ) : (
                  <div className="border rounded-lg max-h-[300px] overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="text-left py-2 px-3 font-medium">Date</th>
                          <th className="text-right py-2 px-3 font-medium">Amount</th>
                          <th className="text-left py-2 px-3 font-medium">Method</th>
                          <th className="text-center py-2 px-3 font-medium">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {paymentHistory.slice(0, 50).map((payment) => (
                          <tr key={payment.id} className="hover:bg-gray-50">
                            <td className="py-2 px-3">{formatDate(payment.date)}</td>
                            <td className="py-2 px-3 text-right font-medium text-green-600">
                              {formatNaira(payment.amount)}
                            </td>
                            <td className="py-2 px-3 capitalize">
                              {payment.method.replace("_", " ")}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <Badge
                                variant="default"
                                className="bg-green-100 text-green-800 text-xs"
                              >
                                {payment.status}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  )
}
